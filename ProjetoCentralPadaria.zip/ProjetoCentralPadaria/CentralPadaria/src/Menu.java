
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Menu extends javax.swing.JFrame {


    public Menu() {
        initComponents();
    }
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu24 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        itmCadastrarFuncionario = new javax.swing.JMenuItem();
        itmListarFuncionario = new javax.swing.JMenuItem();
        itmAlteraFuncionario = new javax.swing.JMenuItem();
        itmExcluirFuncionario = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenu11 = new javax.swing.JMenu();
        jMenu12 = new javax.swing.JMenu();
        jMenu13 = new javax.swing.JMenu();
        jMenu14 = new javax.swing.JMenu();
        jMenu23 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        itmCadastrarCliente = new javax.swing.JMenuItem();
        itmListarClientes = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        itmExcluirCliente = new javax.swing.JMenuItem();
        jMenu15 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenu9 = new javax.swing.JMenu();
        jMenu16 = new javax.swing.JMenu();
        jMenu17 = new javax.swing.JMenu();
        jMenu22 = new javax.swing.JMenu();
        jMenu25 = new javax.swing.JMenu();
        jMenu19 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        itmCadastrarEstoque = new javax.swing.JMenuItem();
        itmListarEstoque = new javax.swing.JMenuItem();
        itmAlterarEstoque = new javax.swing.JMenuItem();
        itmExcluirEstoque = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        jMenu18 = new javax.swing.JMenu();
        jMenu20 = new javax.swing.JMenu();
        jMenu21 = new javax.swing.JMenu();
        jMenu26 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        itmCadastrarProduto = new javax.swing.JMenuItem();
        itmListarProduto = new javax.swing.JMenuItem();
        itmAlterarProduto = new javax.swing.JMenuItem();
        itmExcluirProduto = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Menu Principal ");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Icons/Logo.jpeg"))); // NOI18N

        jMenuBar1.setBackground(new java.awt.Color(255, 255, 204));
        jMenuBar1.setBorder(null);
        jMenuBar1.add(jMenu24);

        jMenu4.setMnemonic('U');
        jMenu4.setText("Funcionários");

        itmCadastrarFuncionario.setText("Cadastrar");
        itmCadastrarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmCadastrarFuncionarioActionPerformed(evt);
            }
        });
        jMenu4.add(itmCadastrarFuncionario);

        itmListarFuncionario.setText("Listar");
        itmListarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmListarFuncionarioActionPerformed(evt);
            }
        });
        jMenu4.add(itmListarFuncionario);

        itmAlteraFuncionario.setText("Alterar");
        itmAlteraFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmAlteraFuncionarioActionPerformed(evt);
            }
        });
        jMenu4.add(itmAlteraFuncionario);

        itmExcluirFuncionario.setText("Excluir");
        itmExcluirFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmExcluirFuncionarioActionPerformed(evt);
            }
        });
        jMenu4.add(itmExcluirFuncionario);

        jMenuBar1.add(jMenu4);
        jMenuBar1.add(jMenu5);
        jMenuBar1.add(jMenu8);
        jMenuBar1.add(jMenu11);
        jMenuBar1.add(jMenu12);
        jMenuBar1.add(jMenu13);
        jMenuBar1.add(jMenu14);
        jMenuBar1.add(jMenu23);

        jMenu1.setText("Clientes");

        itmCadastrarCliente.setText("Cadastrar");
        itmCadastrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmCadastrarClienteActionPerformed(evt);
            }
        });
        jMenu1.add(itmCadastrarCliente);

        itmListarClientes.setText("Listar");
        itmListarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmListarClientesActionPerformed(evt);
            }
        });
        jMenu1.add(itmListarClientes);

        jMenuItem2.setText("Alterar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        itmExcluirCliente.setText("Excluir");
        itmExcluirCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmExcluirClienteActionPerformed(evt);
            }
        });
        jMenu1.add(itmExcluirCliente);

        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu15);
        jMenuBar1.add(jMenu6);
        jMenuBar1.add(jMenu9);
        jMenuBar1.add(jMenu16);
        jMenuBar1.add(jMenu17);
        jMenuBar1.add(jMenu22);
        jMenuBar1.add(jMenu25);
        jMenuBar1.add(jMenu19);

        jMenu3.setText("Estoque");

        itmCadastrarEstoque.setText("Cadastrar");
        itmCadastrarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmCadastrarEstoqueActionPerformed(evt);
            }
        });
        jMenu3.add(itmCadastrarEstoque);

        itmListarEstoque.setText("Listar");
        itmListarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmListarEstoqueActionPerformed(evt);
            }
        });
        jMenu3.add(itmListarEstoque);

        itmAlterarEstoque.setText("Alterar");
        itmAlterarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmAlterarEstoqueActionPerformed(evt);
            }
        });
        jMenu3.add(itmAlterarEstoque);

        itmExcluirEstoque.setText("Excluir");
        itmExcluirEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmExcluirEstoqueActionPerformed(evt);
            }
        });
        jMenu3.add(itmExcluirEstoque);

        jMenuBar1.add(jMenu3);
        jMenuBar1.add(jMenu7);
        jMenuBar1.add(jMenu10);
        jMenuBar1.add(jMenu18);
        jMenuBar1.add(jMenu20);
        jMenuBar1.add(jMenu21);
        jMenuBar1.add(jMenu26);

        jMenu2.setText("Produtos");

        itmCadastrarProduto.setText("Cadastrar");
        itmCadastrarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmCadastrarProdutoActionPerformed(evt);
            }
        });
        jMenu2.add(itmCadastrarProduto);

        itmListarProduto.setText("Listar");
        itmListarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmListarProdutoActionPerformed(evt);
            }
        });
        jMenu2.add(itmListarProduto);

        itmAlterarProduto.setText("Alterar");
        itmAlterarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmAlterarProdutoActionPerformed(evt);
            }
        });
        jMenu2.add(itmAlterarProduto);

        itmExcluirProduto.setText("Excluir");
        itmExcluirProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmExcluirProdutoActionPerformed(evt);
            }
        });
        jMenu2.add(itmExcluirProduto);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(72, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(63, 63, 63))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel3)
                .addContainerGap(63, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void itmExcluirFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmExcluirFuncionarioActionPerformed
String matricula = JOptionPane.showInputDialog(this, "Digite a matrícula do funcionário a ser excluído:");

        if (matricula != null && !matricula.trim().isEmpty()) {
            try {
                // 1- Conectar com o banco de dados
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conectado = DriverManager.getConnection("jdbc:mysql://localhost:3306/padaria", "root", "");

                // 2 - Excluir o funcionário pela matrícula
                String sql = "DELETE FROM funcionarios WHERE matricula = ?";
                PreparedStatement st = conectado.prepareStatement(sql);
                st.setString(1, matricula);
                
                int rowsAffected = st.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Funcionário excluído com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(this, "Nenhum funcionário encontrado com a matrícula fornecida.");
                }

                // Fechar conexões e recursos
                st.close();
                conectado.close();
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Driver não colocado na library");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro nos dados do banco de dados " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Matrícula inválida.");
        }
    }//GEN-LAST:event_itmExcluirFuncionarioActionPerformed

    private void itmCadastrarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmCadastrarFuncionarioActionPerformed
        new CadastrarFuncionario().setVisible(true);
    }//GEN-LAST:event_itmCadastrarFuncionarioActionPerformed

    private void itmListarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmListarFuncionarioActionPerformed
       new ListarFuncionario().setVisible(true);
    }//GEN-LAST:event_itmListarFuncionarioActionPerformed

    private void itmCadastrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmCadastrarClienteActionPerformed
       new CadastrarCliente().setVisible(true);
    }//GEN-LAST:event_itmCadastrarClienteActionPerformed

    private void itmListarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmListarClientesActionPerformed
       new ListarCliente().setVisible(true);
    }//GEN-LAST:event_itmListarClientesActionPerformed

    private void itmExcluirClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmExcluirClienteActionPerformed
// 1- perguntar qual o ID do cliente que quero excluir
        String CPF = JOptionPane.showInputDialog("Qual o CPF do cliente que deseja excluir?");

        // 2- conectar com o banco de dados MySQL
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conectado = DriverManager.getConnection("jdbc:mysql://localhost:3306/padaria", "root", "");

            // 3 - Excluir o cliente digitado da tabela do banco de BD
            PreparedStatement st = conectado.prepareStatement("DELETE FROM cliente WHERE CPF = ?");
            st.setString(1, CPF);
            int resultado = st.executeUpdate(); // executa o DELETE
            if (resultado == 1) {
                // 4- Mostrar uma mensagem indicando que excluiu
                JOptionPane.showMessageDialog(null, "Cliente excluído com sucesso");
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não encontrado");
            }

            // Fechar conexões e recursos
            st.close();
            conectado.close();
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver não colocado na library");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na conexão com o banco de dados: " + ex.getMessage());
        }  
    }//GEN-LAST:event_itmExcluirClienteActionPerformed

    private void itmCadastrarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmCadastrarProdutoActionPerformed
    new CadastrarProduto().setVisible(true);
    }//GEN-LAST:event_itmCadastrarProdutoActionPerformed

    private void itmListarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmListarProdutoActionPerformed
        new ListarProduto().setVisible(true);
    }//GEN-LAST:event_itmListarProdutoActionPerformed

    private void itmExcluirProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmExcluirProdutoActionPerformed
String codigoProduto = JOptionPane.showInputDialog(this, "Digite o código do produto a ser excluído:");

if (codigoProduto != null && !codigoProduto.trim().isEmpty()) {
    try {
        // 1- Conectar com o banco de dados
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conectado = DriverManager.getConnection("jdbc:mysql://localhost:3306/padaria", "root", "");

        // 2 - Excluir o produto pelo código
        String sql = "DELETE FROM produtos WHERE codigoproduto = ?";
        PreparedStatement st = conectado.prepareStatement(sql);
        st.setString(1, codigoProduto);
        
        int rowsAffected = st.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Produto excluído com sucesso.");
        } else {
            JOptionPane.showMessageDialog(this, "Nenhum produto encontrado com o código fornecido.");
        }

        // Fechar conexões e recursos
        st.close();
        conectado.close();
    } catch (ClassNotFoundException ex) {
        JOptionPane.showMessageDialog(null, "Driver não encontrado na library");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro nos dados do banco de dados " + ex.getMessage());
    }
} else {
    JOptionPane.showMessageDialog(this, "Código do produto inválido.");
}
    }//GEN-LAST:event_itmExcluirProdutoActionPerformed

    private void itmCadastrarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmCadastrarEstoqueActionPerformed
new CadastrarEstoque().setVisible(true);
    }//GEN-LAST:event_itmCadastrarEstoqueActionPerformed

    private void itmListarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmListarEstoqueActionPerformed
        new ListarEstoque().setVisible(true);
    }//GEN-LAST:event_itmListarEstoqueActionPerformed

    private void itmExcluirEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmExcluirEstoqueActionPerformed
        String codigoItem = JOptionPane.showInputDialog(this, "Digite o código do item a ser excluído:");

if (codigoItem != null && !codigoItem.trim().isEmpty()) {
    try {
        // 1- Conectar com o banco de dados
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conectado = DriverManager.getConnection("jdbc:mysql://localhost:3306/padaria", "root", "");

        // 2 - Excluir o item de estoque pelo código do item
        String sql = "DELETE FROM estoque WHERE codigoItem = ?";
        PreparedStatement st = conectado.prepareStatement(sql);
        st.setString(1, codigoItem);
        
        int rowsAffected = st.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Item de estoque excluído com sucesso.");
        } else {
            JOptionPane.showMessageDialog(this, "Nenhum item de estoque encontrado com o código fornecido.");
        }

        // Fechar conexões e recursos
        st.close();
        conectado.close();
    } catch (ClassNotFoundException ex) {
        JOptionPane.showMessageDialog(null, "Driver não encontrado na library");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro nos dados do banco de dados " + ex.getMessage());
    }
} else {
    JOptionPane.showMessageDialog(this, "Código do item inválido.");
}
    }//GEN-LAST:event_itmExcluirEstoqueActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
       new AlterarCliente().setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void itmAlteraFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmAlteraFuncionarioActionPerformed
       new AlterarFuncionario().setVisible(true);
    }//GEN-LAST:event_itmAlteraFuncionarioActionPerformed

    private void itmAlterarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmAlterarEstoqueActionPerformed
       new AlterarEstoque().setVisible(true);
    }//GEN-LAST:event_itmAlterarEstoqueActionPerformed

    private void itmAlterarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itmAlterarProdutoActionPerformed
       new AlterarProduto().setVisible(true);
    }//GEN-LAST:event_itmAlterarProdutoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem itmAlteraFuncionario;
    private javax.swing.JMenuItem itmAlterarEstoque;
    private javax.swing.JMenuItem itmAlterarProduto;
    private javax.swing.JMenuItem itmCadastrarCliente;
    private javax.swing.JMenuItem itmCadastrarEstoque;
    private javax.swing.JMenuItem itmCadastrarFuncionario;
    private javax.swing.JMenuItem itmCadastrarProduto;
    private javax.swing.JMenuItem itmExcluirCliente;
    private javax.swing.JMenuItem itmExcluirEstoque;
    private javax.swing.JMenuItem itmExcluirFuncionario;
    private javax.swing.JMenuItem itmExcluirProduto;
    private javax.swing.JMenuItem itmListarClientes;
    private javax.swing.JMenuItem itmListarEstoque;
    private javax.swing.JMenuItem itmListarFuncionario;
    private javax.swing.JMenuItem itmListarProduto;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu13;
    private javax.swing.JMenu jMenu14;
    private javax.swing.JMenu jMenu15;
    private javax.swing.JMenu jMenu16;
    private javax.swing.JMenu jMenu17;
    private javax.swing.JMenu jMenu18;
    private javax.swing.JMenu jMenu19;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu20;
    private javax.swing.JMenu jMenu21;
    private javax.swing.JMenu jMenu22;
    private javax.swing.JMenu jMenu23;
    private javax.swing.JMenu jMenu24;
    private javax.swing.JMenu jMenu25;
    private javax.swing.JMenu jMenu26;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    // End of variables declaration//GEN-END:variables
}
